require 'test_helper'

class TagsHelperTest < ActionView::TestCase
end
